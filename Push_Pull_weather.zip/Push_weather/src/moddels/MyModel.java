package moddels;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

public class MyModel {
    public static final String TEMPERATUR = "temperaturInGrad";
    public static final String LUFTFEUCHTIGKEIT = "luftfeuchtigkeitInProzent";

    private List<Wetter> wetters = new ArrayList<Wetter>();
    private List<PropertyChangeListener> listener = new ArrayList<PropertyChangeListener>();

    public class Wetter {

        private Integer temperatur_in_grad;

        private Integer luftfeuchtigkeit_in_prozent;

        public Wetter(Integer temperatur_in_grad, Integer luftfeuchtigkeit_in_prozent) {
            this.temperatur_in_grad = temperatur_in_grad;
            this.luftfeuchtigkeit_in_prozent = luftfeuchtigkeit_in_prozent;
        }

        public Integer getTemperatur_in_grad() {

            return temperatur_in_grad;
        }

        public void setTemperatur_in_grad(Integer temperatur_in_grad) {
            notifyListeners(
                    this,
                    TEMPERATUR,
                    this.temperatur_in_grad,
                    this.temperatur_in_grad = temperatur_in_grad);

        }

        public Integer getLuftfeuchtigkeit_in_prozent() {
            return luftfeuchtigkeit_in_prozent;
        }

        public void setLuftfeuchtigkeit_in_prozent(Integer luftfeuchtigkeit_in_prozent) {
            notifyListeners(
                    this,
                    LUFTFEUCHTIGKEIT,
                    this.luftfeuchtigkeit_in_prozent,
                    this.luftfeuchtigkeit_in_prozent = luftfeuchtigkeit_in_prozent);
        }
    }

    public List<Wetter> getWetter() {
        return wetters;
    }

    public MyModel() {
        // Falls man mehrere Datensätze hat könnte man sie hier alle eintragen
        wetters.add(new Wetter(1,1 ));
    }

    private void notifyListeners(Object object, String property, Integer oldValue, Integer newValue) {
        for (PropertyChangeListener name : listener) {
            name.propertyChange(new PropertyChangeEvent(this, property, oldValue, newValue));
        }
    }

    public void addChangeListener(PropertyChangeListener newListener) {
        listener.add(newListener);
    }

}
