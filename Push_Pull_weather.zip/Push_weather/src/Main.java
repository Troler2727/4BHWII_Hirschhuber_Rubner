
import moddels.*;
public class Main {

    public static void main(String[] args) {

        //pull

        MyModel model = new MyModel();
        MyObserver observer = new MyObserver(model);
        // Holt das wetter Object daher pull
        for (MyModel.Wetter wetter : model.getWetter()) {
            System.out.println(wetter.getTemperatur_in_grad());;
        }
       // eventuelle Änderungen sind mit java.beans auch möglich sollte dass gewünscht sein
        for (MyModel.Wetter wetter : model.getWetter()) {
            wetter.setTemperatur_in_grad(wetter.getTemperatur_in_grad() + 1);
        }


        // push

        //create subject
        MyTopic temperatur = new MyTopic();
        MyTopic luftfeuchtigkeit = new MyTopic();

        //create observers
        Observer obj1 = new MyTopicSubscriber("Obj1");
        Observer obj2 = new MyTopicSubscriber("Obj2");
        Observer obj3 = new MyTopicSubscriber("Obj3");

        //register observers to the subject
        temperatur.register(obj1);
        temperatur.register(obj2);
        luftfeuchtigkeit.register(obj3);

        //attach observer to subject
        obj1.setSubject(temperatur);
        obj2.setSubject(temperatur);
        obj3.setSubject(luftfeuchtigkeit);

        //check if any update is available
        obj1.update();

        //now send message to subject
        temperatur.postMessage(1);
    }
}